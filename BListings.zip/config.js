﻿
        module.exports = {
            bot: {
                token: "NzU5NDEyODA3MDMxNzE3OTA4.X29ISg.8dxw4DITLPvBUJvzLZsgpUR7h-M",
                prefix: "b!",
                owners: ["529815278456930314"],
                mongourl: "mongodb+srv://Bryden:Bry277272@cluster0.tlnrq.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
                servers: {
                    token: "NzY5NTY1OTc2NzAxNDM1OTE1.X5Q4Kg.zxRgRm63RBmO69u_OGwAuN4Vkvw",
                    prefix: "?"
                }
            },
        
            website: {
                callback: "https://www.blistings.xyz/callback",
                secret: "1zHRyFiFKWBssFaJGo7ZnzA7U3Z5Z6il",
                clientID: "759412807031717908", 
                tags: [ "Moderation", "Fun", "Minecraft","Economy","Guard","Anime","Invite","Music","Logging", "Web Dashboard", "Reddit", "Youtube", "Twitch", "Crypto", "Leveling", "Game", "Roleplay", "Utility", "Turkish" ],
                languages: [
                    { flag: 'gb', code: 'en', name: 'English' },
                    { flag: 'tr', code: 'tr', name: 'Türkçe' },
                    { flag: 'de', code: 'de', name: 'Deutsch' }
                ],
                servers: {
                    tags: [
                    {
                        icon: "fal fa-code",
                        name: "Development"
                    },
                    {
                        icon: "fal fa-play",
                        name: "Stream"
                    },
                    {
                        icon: "fal fa-camera",
                        name: "Media"
                    },
                    {
                        icon: 'fal fa-building',
                        name: 'Company'
                    },
                    {
                        icon: 'fal fa-gamepad',
                        name: 'Game'
                    },
                    {
                        icon: 'fal fa-icons',
                        name: 'Emoji'
                    },
                    {
                        icon: 'fal fa-robot',
                        name: 'Bot List'
                    },
                    {
                        icon: 'fal fa-server',
                        name: 'Server List'
                    },
                    {
                        icon: 'fal fa-moon-stars',
                        name: 'Turkish'
                    },
                    {
                        icon: 'fab fa-discord',
                        name: 'Support'
                    },
                    {
                        icon: 'fal fa-volume',
                        name: 'Sound'
                    },
                    {
                        icon: 'fal fa-comments',
                        name: 'Chatting'
                    },
                    {
                      icon: "fal fa-comment-slash",
                      name: "Challange"
                    },
                    {
                      icon: "fal fa-hand-rock",
                      name: "Protest"
                    },
                    {
                      icon: "fal fa-headphones-alt",
                      name: "Roleplay"
                    },
                    {
                      icon: "fal fa-grin-alt",
                      name: "Meme"
                    },
                    {
                      icon: "fal fa-shopping-cart",
                      name: "Shop"
                    },
                    {
                      icon: "fal fa-desktop",
                      name: "Technology"
                    },
                    {
                      icon: "fal fa-laugh",
                      name: "Fun"
                    },
                    {
                      icon: "fal fa-share-alt",
                      name: "Social"
                    },
                    {
                      icon: "fal fa-laptop",
                      name: "E-Spor"
                    },
                    {
                      icon: 'fal fa-palette',
                      name: 'Design'
                    },
                    {
                      icon: 'fal fa-users',
                      name: 'Community'
                    }
                    ]                
                }
            },
        
            server: {
                id: "852580838921994240",
                invite: "https://discord.gg/CqgCUE2Dsf",
                roles: {
                    administrator: "852580838921994245",
                    moderator: "852580838921994244",
                    profile: {
                        sitecreator : "",
                        booster: "",
                        sponsor: "",
                        supporter: "867445228658360330",
                        partnerRole: "853416155272577084"
                    },
                    codeshare: {
                        javascript: "868972998659543110",
                        html: "868972998659543110",
                        substructure: "868972998659543110",
                        bdfd: "868972998659543110", 
                        fiveInvite: "868972998659543110",
                        tenInvite: "868972998659543110",
                        fifteenInvite: "868972998659543110",
                        twentyInvite: "868972998659543110"
                    },
                    botlist: {
                        developer: "854122075400306708",
                        certified_developer: "867146438496878612",
                        bot: "852580838921994243",
                        certified_bot: "867146597310005258",
                    }
                },
                channels: {
                    codelog: "866509296254058536",
                    login: "866509332925120522",
                    webstatus: "871902272420974652",
                    uptimelog: "866509296254058536",
                    botlog: "866509296254058536",
                    votes: "868973322032005130"
                }
            }
        
        
        }